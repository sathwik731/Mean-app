// config/database.js

module.exports = {
	// url: 'mongodb://<dbuser>:<dbpassword>@ds161099.mlab.com:61099/hoteldb',
	url: "mongodb://localhost:27017/hoteldb",
};
